/**
 * FitCalc Pro - Aplikasi Web Kalkulator Kebugaran Tubuh
 * Main App Controller & UI Interactivity
 */

document.addEventListener('DOMContentLoaded', () => {
    // Inisialisasi state
    let isDarkMode = localStorage.getItem('fitcalc_theme') === 'dark' || 
        (!('fitcalc_theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);

    // Terapkan Tema Awal
    applyTheme(isDarkMode);

    // Inisialisasi Riwayat
    FitnessHistory.loadSampleDataIfEmpty();
    renderHistoryTable();

    // Event Listener Ganti Tema (Dark / Light)
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            isDarkMode = !isDarkMode;
            localStorage.setItem('fitcalc_theme', isDarkMode ? 'dark' : 'light');
            applyTheme(isDarkMode);
            // Re-render chart jika ada
            refreshAllCharts();
        });
    }

    // Inisialisasi Tab Navigation
    setupTabNavigation();

    // Sinkronisasi Gender Toggle (Pria / Wanita) & Form Listeners
    setupFormListeners();

    // Setup Water Tracker Interaktif
    setupWaterTracker();

    // Jalankan kalkulasi perdana dengan nilai default agar user langsung melihat dashboard siap pakai
    calculateAllInOne();
});

/**
 * Terapkan Tema Gelap / Terang
 */
function applyTheme(isDark) {
    const html = document.documentElement;
    const themeIcon = document.getElementById('theme-icon');
    const themeText = document.getElementById('theme-text');

    if (isDark) {
        html.classList.add('dark');
        if (themeIcon) themeIcon.className = 'fa-solid fa-sun text-amber-400';
        if (themeText) themeText.textContent = 'Mode Terang';
    } else {
        html.classList.remove('dark');
        if (themeIcon) themeIcon.className = 'fa-solid fa-moon text-indigo-600';
        if (themeText) themeText.textContent = 'Mode Gelap';
    }
}

/**
 * Setup Navigasi Antar Tab
 */
function setupTabNavigation() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-content-panel');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-tab');

            // Set active button
            tabButtons.forEach(b => {
                b.classList.remove('active', 'bg-indigo-600', 'text-white');
                b.classList.add('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100', 'dark:hover:bg-slate-800');
            });
            btn.classList.add('active', 'bg-indigo-600', 'text-white');
            btn.classList.remove('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100', 'dark:hover:bg-slate-800');

            // Show target panel
            tabPanels.forEach(panel => {
                if (panel.id === targetId) {
                    panel.classList.remove('hidden');
                } else {
                    panel.classList.add('hidden');
                }
            });

            // Re-render chart khusus tab jika aktif
            if (targetId === 'tab-history') {
                renderHistoryChart();
            } else if (targetId === 'tab-heart-rate') {
                calculateIndividualHeartRate();
            }
        });
    });
}

/**
 * Setup Listeners untuk input & formulir
 */
function setupFormListeners() {
    // 1. All In One Form
    const allInOneForm = document.getElementById('all-in-one-form');
    if (allInOneForm) {
        allInOneForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateAllInOne();
        });
    }

    // Toggle Field Pinggul (Hip) khusus Wanita di Form All-in-One & Body Fat
    const genderRadios = document.querySelectorAll('input[name="aio-gender"]');
    genderRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            const hipContainer = document.getElementById('aio-hip-container');
            if (hipContainer) {
                if (e.target.value === 'female') {
                    hipContainer.classList.remove('hidden');
                } else {
                    hipContainer.classList.add('hidden');
                }
            }
        });
    });

    // 2. Individual BMI Form
    const bmiForm = document.getElementById('bmi-form');
    if (bmiForm) {
        bmiForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividualBMI();
        });
    }

    // 3. Individual Calorie Form
    const calorieForm = document.getElementById('calorie-form');
    if (calorieForm) {
        calorieForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividualCalorie();
        });
    }

    // 4. Individual Body Fat Form
    const bfForm = document.getElementById('bodyfat-form');
    if (bfForm) {
        bfForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividualBodyFat();
        });
    }
    const bfGenderRadios = document.querySelectorAll('input[name="bf-gender"]');
    bfGenderRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            const hipContainer = document.getElementById('bf-hip-container');
            if (hipContainer) {
                if (e.target.value === 'female') {
                    hipContainer.classList.remove('hidden');
                } else {
                    hipContainer.classList.add('hidden');
                }
            }
        });
    });

    // 5. Individual Hydration Form
    const hydroForm = document.getElementById('hydro-form');
    if (hydroForm) {
        hydroForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividualHydration();
        });
    }

    // 6. Individual Heart Rate Form
    const hrForm = document.getElementById('heartrate-form');
    if (hrForm) {
        hrForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividualHeartRate();
        });
    }

    // 7. Individual 1RM Form
    const onermForm = document.getElementById('onerm-form');
    if (onermForm) {
        onermForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateIndividual1RM();
        });
    }

    // Tombol Isi Data Contoh (Demo)
    const fillSampleBtn = document.getElementById('fill-sample-btn');
    if (fillSampleBtn) {
        fillSampleBtn.addEventListener('click', () => {
            document.getElementById('aio-name').value = 'Wahyu Pratama';
            document.getElementById('aio-age').value = 26;
            document.getElementById('aio-height').value = 172;
            document.getElementById('aio-weight').value = 68;
            document.getElementById('aio-waist').value = 82;
            document.getElementById('aio-neck').value = 38;
            document.getElementById('aio-activity').value = '1.55';
            document.getElementById('aio-goal').value = 'cut_mild';
            document.getElementById('aio-diet').value = 'high_protein';
            calculateAllInOne();
        });
    }

    // Tombol Cetak Laporan PDF
    const printReportBtn = document.getElementById('print-report-btn');
    if (printReportBtn) {
        printReportBtn.addEventListener('click', () => {
            window.print();
        });
    }

    // Tombol Simpan Riwayat dari All-in-One
    const saveToHistoryBtn = document.getElementById('save-history-btn');
    if (saveToHistoryBtn) {
        saveToHistoryBtn.addEventListener('click', () => {
            saveCurrentAssessmentToHistory();
        });
    }

    // Tombol Ekspor CSV
    const exportCsvBtn = document.getElementById('export-csv-btn');
    if (exportCsvBtn) {
        exportCsvBtn.addEventListener('click', () => {
            FitnessHistory.exportToCSV();
        });
    }

    // Tombol Bersihkan Riwayat
    const clearHistoryBtn = document.getElementById('clear-history-btn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', () => {
            if (confirm('Apakah Anda yakin ingin menghapus seluruh catatan riwayat?')) {
                FitnessHistory.clearAll();
                renderHistoryTable();
                renderHistoryChart();
            }
        });
    }
}

/**
 * Variabel penyimpan hasil assessment aktif untuk disimpan ke riwayat
 */
let currentAssessment = null;

/**
 * KALKULASI UTAMA: All-In-One Fitness Assessment
 */
function calculateAllInOne() {
    const name = document.getElementById('aio-name')?.value || 'Tamu';
    const genderElem = document.querySelector('input[name="aio-gender"]:checked');
    const gender = genderElem ? genderElem.value : 'male';
    const age = parseInt(document.getElementById('aio-age')?.value) || 25;
    const height = parseFloat(document.getElementById('aio-height')?.value) || 170;
    const weight = parseFloat(document.getElementById('aio-weight')?.value) || 65;
    const waist = parseFloat(document.getElementById('aio-waist')?.value) || 80;
    const neck = parseFloat(document.getElementById('aio-neck')?.value) || 37;
    const hip = parseFloat(document.getElementById('aio-hip')?.value) || 95;
    const activityLevel = document.getElementById('aio-activity')?.value || '1.375';
    const goal = document.getElementById('aio-goal')?.value || 'maintain';
    const dietType = document.getElementById('aio-diet')?.value || 'balanced';

    // 1. BMI & Berat Ideal
    const bmiResult = FitnessCalculator.calculateBMI(weight, height);
    const idealWeight = FitnessCalculator.calculateIdealWeight(gender, height);

    // 2. BMR & TDEE
    const bmr = FitnessCalculator.calculateBMR(gender, weight, height, age);
    const tdee = FitnessCalculator.calculateTDEE(bmr, activityLevel);
    const macros = FitnessCalculator.calculateMacros(tdee, goal, dietType);

    // 3. Lemak Tubuh (US Navy)
    const bodyFat = FitnessCalculator.calculateBodyFatNavy(gender, height, waist, neck, hip, weight);

    // 4. Kebutuhan Hidrasi
    const hydration = FitnessCalculator.calculateHydration(weight, 45);

    // 5. Heart Rate Zones
    const hrZones = FitnessCalculator.calculateHeartRateZones(age);

    // 6. Skor Kebugaran
    const fitnessScore = FitnessCalculator.calculateFitnessScore({
        bmi: bmiResult ? bmiResult.bmi : 22,
        bodyFat: bodyFat ? bodyFat.bodyFatPercent : null,
        activityLevel
    });

    // Simpan ke state
    currentAssessment = {
        name,
        gender,
        age,
        height,
        weight,
        bmi: bmiResult.bmi,
        bmiCategory: bmiResult.category,
        tdee: macros.targetCalories,
        bodyFat: bodyFat ? bodyFat.bodyFatPercent : null,
        score: fitnessScore.score,
        goal: getGoalLabel(goal),
        date: new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
    };

    // Update UI Tampilan
    updateAllInOneUI({
        name,
        gender,
        age,
        height,
        weight,
        bmiResult,
        idealWeight,
        bmr,
        tdee,
        macros,
        bodyFat,
        hydration,
        hrZones,
        fitnessScore,
        goal,
        dietType
    });
}

/**
 * Update Elemen UI untuk All-in-One
 */
function updateAllInOneUI(data) {
    const isDark = document.documentElement.classList.contains('dark');

    // 1. Header Ringkasan & Skor
    const userSummaryName = document.getElementById('summary-user-name');
    if (userSummaryName) userSummaryName.textContent = data.name;

    const summaryScore = document.getElementById('summary-score-value');
    if (summaryScore) summaryScore.textContent = data.fitnessScore.score;

    const summaryRatingBadge = document.getElementById('summary-score-rating');
    if (summaryRatingBadge) {
        summaryRatingBadge.textContent = data.fitnessScore.ratingLabel;
        summaryRatingBadge.className = `px-3 py-1 rounded-full text-xs font-semibold ${data.fitnessScore.badgeColor}`;
    }

    // 2. Kartu BMI & Berat Ideal
    const bmiVal = document.getElementById('res-bmi-value');
    if (bmiVal) bmiVal.textContent = data.bmiResult.bmi;

    const bmiCatBadge = document.getElementById('res-bmi-category');
    if (bmiCatBadge) {
        bmiCatBadge.textContent = data.bmiResult.category;
        bmiCatBadge.className = `inline-block px-2.5 py-1 rounded-md text-xs font-semibold ${data.bmiResult.colorClass}`;
    }

    const bmiAdvice = document.getElementById('res-bmi-advice');
    if (bmiAdvice) bmiAdvice.textContent = data.bmiResult.advice;

    const bmiNeedle = document.getElementById('bmi-needle');
    if (bmiNeedle) {
        bmiNeedle.style.left = `${data.bmiResult.gaugePercentage}%`;
    }

    const idealRangeText = document.getElementById('res-ideal-weight-range');
    if (idealRangeText) {
        idealRangeText.textContent = `${data.bmiResult.idealWeightMin} - ${data.bmiResult.idealWeightMax} kg`;
    }

    const devineText = document.getElementById('res-ideal-broca');
    if (devineText) {
        devineText.textContent = `${data.idealWeight.broca} kg`;
    }

    // 3. Kalori, BMR & TDEE
    const bmrElem = document.getElementById('res-bmr-value');
    if (bmrElem) bmrElem.textContent = `${data.bmr.toLocaleString('id-ID')} kkal/hari`;

    const tdeeElem = document.getElementById('res-tdee-value');
    if (tdeeElem) tdeeElem.textContent = `${data.tdee.toLocaleString('id-ID')} kkal/hari`;

    const targetCalElem = document.getElementById('res-target-calories');
    if (targetCalElem) targetCalElem.textContent = `${data.macros.targetCalories.toLocaleString('id-ID')} kkal`;

    const targetCalNote = document.getElementById('res-target-calories-note');
    if (targetCalNote) {
        const diff = data.macros.calorieDifference;
        if (diff < 0) {
            targetCalNote.textContent = `Defisit kalori ${Math.abs(diff)} kkal di bawah TDEE harian.`;
        } else if (diff > 0) {
            targetCalNote.textContent = `Surplus kalori ${diff} kkal di atas TDEE untuk pertumbuhan massa.`;
        } else {
            targetCalNote.textContent = `Kalori pemeliharaan (Maintenance) stabil seimbang.`;
        }
    }

    // Macro Grams & Bars
    const carbGrams = document.getElementById('res-carb-grams');
    if (carbGrams) carbGrams.textContent = `${data.macros.carbGrams} g`;

    const proteinGrams = document.getElementById('res-protein-grams');
    if (proteinGrams) proteinGrams.textContent = `${data.macros.proteinGrams} g`;

    const fatGrams = document.getElementById('res-fat-grams');
    if (fatGrams) fatGrams.textContent = `${data.macros.fatGrams} g`;

    // Render Doughnut Chart Macro
    FitnessCharts.renderMacroChart('aio-macro-chart', data.macros, isDark);

    // 4. Lemak Tubuh & Komposisi
    const bfCard = document.getElementById('res-bodyfat-card');
    const bfVal = document.getElementById('res-bodyfat-value');
    const bfCat = document.getElementById('res-bodyfat-cat');
    const bfFatMass = document.getElementById('res-fat-mass');
    const bfLeanMass = document.getElementById('res-lean-mass');

    if (data.bodyFat) {
        if (bfCard) bfCard.classList.remove('hidden');
        if (bfVal) bfVal.textContent = `${data.bodyFat.bodyFatPercent}%`;
        if (bfCat) {
            bfCat.textContent = data.bodyFat.category;
            bfCat.className = `inline-block px-2.5 py-0.5 rounded text-xs font-semibold ${data.bodyFat.colorClass}`;
        }
        if (bfFatMass) bfFatMass.textContent = `${data.bodyFat.fatMassKg} kg`;
        if (bfLeanMass) bfLeanMass.textContent = `${data.bodyFat.leanMassKg} kg`;
    } else {
        if (bfCard) bfCard.classList.add('hidden');
    }

    // 5. Hidrasi Tubuh
    const waterLiters = document.getElementById('res-water-liters');
    if (waterLiters) waterLiters.textContent = `${data.hydration.totalLiters} Liter`;

    const waterGlasses = document.getElementById('res-water-glasses');
    if (waterGlasses) waterGlasses.textContent = `~${data.hydration.totalGlasses} Gelas (@250ml)`;

    // 6. Heart Rate Zones Bar Chart & Quick Cards
    const maxHrVal = document.getElementById('res-max-hr');
    if (maxHrVal) maxHrVal.textContent = `${data.hrZones.maxHr} BPM`;

    const fatburnHr = document.getElementById('res-fatburn-hr');
    if (fatburnHr) {
        const z2 = data.hrZones.zones[1];
        fatburnHr.textContent = `${z2.minBpm} - ${z2.maxBpm} BPM`;
    }

    FitnessCharts.renderHeartRateChart('aio-heartrate-chart', data.hrZones.zones, isDark);

    // 7. Tips Rekomendasi Terpersonalisasi
    generatePersonalizedRecommendations(data);
}

/**
 * Buat Rekomendasi Nutrisi & Latihan Terpersonalisasi
 */
function generatePersonalizedRecommendations(data) {
    const listElem = document.getElementById('res-recommendations-list');
    if (!listElem) return;

    const tips = [];

    // Tips Berdasarkan BMI
    if (data.bmiResult.bmi >= 25) {
        tips.push({
            icon: 'fa-solid fa-person-running',
            color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/40',
            title: 'Kombinasi Kardio Zona 2 & Latihan Beban',
            desc: `Lakukan jalan cepat atau jogging santai di detak jantung ${data.hrZones.zones[1].minBpm}-${data.hrZones.zones[1].maxBpm} BPM selama 30-45 menit, 3-4 kali seminggu untuk memaksimalkan pembakaran lemak tanpa membuat tubuh terlalu lelah.`
        });
        tips.push({
            icon: 'fa-solid fa-plate-wheat',
            color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40',
            title: 'Kendalikan Kalori & Tingkatkan Asupan Serat',
            desc: `Targetkan ${data.macros.targetCalories} kkal/hari. Utamakan sayuran hijau, buah bervolume tinggi, serta protein tinggi (${data.macros.proteinGrams}g) agar rasa kenyang bertahan lama dan massa otot terjaga.`
        });
    } else if (data.bmiResult.bmi < 18.5) {
        tips.push({
            icon: 'fa-solid fa-dumbbell',
            color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40',
            title: 'Fokus Latihan Beban Progresif (Hypertrophy)',
            desc: `Latihan kekuatan 3-4 hari seminggu dengan fokus gerakan gabungan (compound movements: squat, push-up, bench press, deadlift) untuk merangsang pembentukan massa otot bukan hanya lemak.`
        });
        tips.push({
            icon: 'fa-solid fa-bowl-food',
            color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/40',
            title: 'Surplus Kalori Bernutrisi Tinggi',
            desc: `Konsumsi kalori lebih tinggi (~${data.macros.targetCalories} kkal) dengan camilan padat nutrisi seperti kacang-kacangan, susu, alpukat, telur, dan smoothies protein.`
        });
    } else {
        tips.push({
            icon: 'fa-solid fa-heart-pulse',
            color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40',
            title: 'Pertahankan Kebugaran & Fleksibilitas Tubuh',
            desc: `Kombinasikan latihan kardio moderat 150 menit per minggu dengan latihan penguatan otot 2 kali seminggu untuk menjaga stamina dan kesehatan sendi.`
        });
    }

    // Tips Hidrasi
    tips.push({
        icon: 'fa-solid fa-droplet',
        color: 'text-cyan-500 bg-cyan-50 dark:bg-cyan-950/40',
        title: 'Target Hidrasi Harian',
        desc: `Minum minimal ${data.hydration.totalLiters} liter air per hari (sekitar ${data.hydration.totalGlasses} gelas) secara berkala dari bangun tidur hingga malam hari untuk mendukung metabolisme optimal.`
    });

    // Render HTML Tips
    listElem.innerHTML = tips.map(t => `
        <div class="flex items-start gap-4 p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-800 transition">
            <div class="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${t.color}">
                <i class="${t.icon} text-lg"></i>
            </div>
            <div>
                <h4 class="font-bold text-slate-800 dark:text-slate-100 text-sm mb-1">${t.title}</h4>
                <p class="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">${t.desc}</p>
            </div>
        </div>
    `).join('');
}

/**
 * Simpan kalkulasi saat ini ke Riwayat
 */
function saveCurrentAssessmentToHistory() {
    if (!currentAssessment) {
        alert('Lakukan kalkulasi terlebih dahulu.');
        return;
    }

    const success = FitnessHistory.add(currentAssessment);
    if (success) {
        const btn = document.getElementById('save-history-btn');
        if (btn) {
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-check text-emerald-500 mr-2"></i>Tersimpan di Riwayat!';
            btn.classList.add('border-emerald-500', 'text-emerald-600');
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.classList.remove('border-emerald-500', 'text-emerald-600');
            }, 2500);
        }
        renderHistoryTable();
        renderHistoryChart();
    }
}

/**
 * Render Tabel Riwayat
 */
function renderHistoryTable() {
    const list = FitnessHistory.getAll();
    const tbody = document.getElementById('history-table-body');
    const emptyState = document.getElementById('history-empty-state');
    const tableContainer = document.getElementById('history-table-container');

    if (!tbody) return;

    if (list.length === 0) {
        if (emptyState) emptyState.classList.remove('hidden');
        if (tableContainer) tableContainer.classList.add('hidden');
        return;
    }

    if (emptyState) emptyState.classList.add('hidden');
    if (tableContainer) tableContainer.classList.remove('hidden');

    tbody.innerHTML = list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition border-b border-slate-100 dark:border-slate-800">
            <td class="py-3 px-4 text-xs font-medium text-slate-700 dark:text-slate-200">${item.date}</td>
            <td class="py-3 px-4 text-xs font-semibold text-slate-800 dark:text-slate-100">${item.name}</td>
            <td class="py-3 px-4 text-xs text-slate-600 dark:text-slate-300 font-bold">${item.weight} kg</td>
            <td class="py-3 px-4 text-xs">
                <span class="font-bold text-indigo-600 dark:text-indigo-400">${item.bmi}</span>
                <span class="block text-[10px] text-slate-500 dark:text-slate-400">${item.bmiCategory}</span>
            </td>
            <td class="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">${item.tdee} kkal</td>
            <td class="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">${item.bodyFat ? item.bodyFat + '%' : '-'}</td>
            <td class="py-3 px-4 text-xs">
                <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                    ${item.score}/100
                </span>
            </td>
            <td class="py-3 px-4 text-xs text-slate-500 dark:text-slate-400">${item.goal}</td>
            <td class="py-3 px-4 text-xs text-right">
                <button onclick="deleteHistoryEntry('${item.id}')" title="Hapus Entri" class="text-rose-500 hover:text-rose-700 p-1 rounded hover:bg-rose-50 dark:hover:bg-rose-950/50 transition">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

/**
 * Global function untuk menghapus satu entri riwayat
 */
window.deleteHistoryEntry = function(id) {
    if (confirm('Hapus catatan kebugaran ini?')) {
        FitnessHistory.remove(id);
        renderHistoryTable();
        renderHistoryChart();
    }
};

/**
 * Render Grafik Riwayat
 */
function renderHistoryChart() {
    const list = FitnessHistory.getAll().slice().reverse(); // Urutan kronologis
    const isDark = document.documentElement.classList.contains('dark');
    FitnessCharts.renderHistoryChart('history-trend-chart', list, isDark);
}

/**
 * Re-render semua grafik saat ganti tema
 */
function refreshAllCharts() {
    if (currentAssessment) {
        calculateAllInOne();
    }
    renderHistoryChart();
}

/**
 * Helper label tujuan
 */
function getGoalLabel(goalKey) {
    const map = {
        'cut_mild': 'Turunkan Berat (Ringan)',
        'cut_opt': 'Defisit Lemak Optimal (-20%)',
        'cut_aggressive': 'Defisit Ketat (-25%)',
        'maintain': 'Pertahankan Berat Badan',
        'bulk_lean': 'Naikkan Otot Ramping (Lean Bulk)',
        'bulk_fast': 'Bulking Cepat'
    };
    return map[goalKey] || 'Pertahankan Berat';
}

/**
 * Setup Water Tracker Interaktif (Gelas Air Harian)
 */
let loggedGlasses = 0;
const MAX_LOG_GLASSES = 12;

function setupWaterTracker() {
    const glassesContainer = document.getElementById('water-glasses-interactive');
    const logText = document.getElementById('water-logged-text');
    const resetBtn = document.getElementById('reset-water-btn');

    if (!glassesContainer) return;

    // Baca dari session/local storage jika ada
    const savedGlasses = parseInt(localStorage.getItem('fitcalc_today_glasses')) || 0;
    loggedGlasses = savedGlasses;

    function renderGlassesUI() {
        glassesContainer.innerHTML = '';
        for (let i = 1; i <= MAX_LOG_GLASSES; i++) {
            const isFilled = i <= loggedGlasses;
            const glassBtn = document.createElement('button');
            glassBtn.type = 'button';
            glassBtn.className = `p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition transform active:scale-95 ${
                isFilled 
                    ? 'border-cyan-400 bg-cyan-50 dark:bg-cyan-950/50 text-cyan-600 dark:text-cyan-400 shadow-xs' 
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/40 text-slate-400 hover:border-cyan-300'
            }`;
            glassBtn.innerHTML = `
                <i class="fa-solid fa-glass-water text-xl ${isFilled ? 'text-cyan-500 scale-110 transition' : 'text-slate-300 dark:text-slate-600'}"></i>
                <span class="text-[10px] font-bold">${i * 250} ml</span>
            `;

            glassBtn.addEventListener('click', () => {
                if (loggedGlasses === i) {
                    loggedGlasses = i - 1; // Toggle off if clicked current
                } else {
                    loggedGlasses = i;
                }
                localStorage.setItem('fitcalc_today_glasses', loggedGlasses);
                renderGlassesUI();
            });

            glassesContainer.appendChild(glassBtn);
        }

        if (logText) {
            const totalMl = loggedGlasses * 250;
            const totalLit = (totalMl / 1000).toFixed(2);
            logText.textContent = `${loggedGlasses} dari 10-12 gelas (${totalLit} L tercatat hari ini)`;
        }
    }

    renderGlassesUI();

    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            loggedGlasses = 0;
            localStorage.setItem('fitcalc_today_glasses', 0);
            renderGlassesUI();
        });
    }
}

/**
 * ---------------------------------------------
 * LOGIKA KALKULATOR INDIVIDUAL (MANDIRI)
 * ---------------------------------------------
 */

// 1. Individual BMI Calculator
function calculateIndividualBMI() {
    const weight = parseFloat(document.getElementById('ind-bmi-weight').value);
    const height = parseFloat(document.getElementById('ind-bmi-height').value);
    const gender = document.querySelector('input[name="ind-bmi-gender"]:checked').value;

    const res = FitnessCalculator.calculateBMI(weight, height);
    const ideal = FitnessCalculator.calculateIdealWeight(gender, height);

    if (!res) return;

    document.getElementById('ind-bmi-result-box').classList.remove('hidden');
    document.getElementById('ind-bmi-num').textContent = res.bmi;
    document.getElementById('ind-bmi-badge').textContent = res.category;
    document.getElementById('ind-bmi-badge').className = `px-3 py-1 rounded-full text-xs font-bold ${res.colorClass}`;
    document.getElementById('ind-bmi-advice').textContent = res.advice;

    document.getElementById('ind-ideal-range').textContent = `${res.idealWeightMin} - ${res.idealWeightMax} kg`;
    document.getElementById('ind-ideal-broca').textContent = `${ideal.broca} kg`;
    document.getElementById('ind-ideal-devine').textContent = `${ideal.devine} kg`;
    document.getElementById('ind-ideal-robinson').textContent = `${ideal.robinson} kg`;
}

// 2. Individual Calorie & TDEE Calculator
function calculateIndividualCalorie() {
    const gender = document.querySelector('input[name="ind-cal-gender"]:checked').value;
    const age = parseInt(document.getElementById('ind-cal-age').value);
    const height = parseFloat(document.getElementById('ind-cal-height').value);
    const weight = parseFloat(document.getElementById('ind-cal-weight').value);
    const activity = document.getElementById('ind-cal-activity').value;
    const goal = document.getElementById('ind-cal-goal').value;
    const diet = document.getElementById('ind-cal-diet').value;

    const bmr = FitnessCalculator.calculateBMR(gender, weight, height, age);
    const tdee = FitnessCalculator.calculateTDEE(bmr, activity);
    const macros = FitnessCalculator.calculateMacros(tdee, goal, diet);

    document.getElementById('ind-cal-result-box').classList.remove('hidden');
    document.getElementById('ind-cal-bmr').textContent = `${bmr.toLocaleString('id-ID')} kkal`;
    document.getElementById('ind-cal-tdee').textContent = `${tdee.toLocaleString('id-ID')} kkal`;
    document.getElementById('ind-cal-target').textContent = `${macros.targetCalories.toLocaleString('id-ID')} kkal/hari`;

    document.getElementById('ind-cal-carb').textContent = `${macros.carbGrams}g (${macros.carbCalories} kkal)`;
    document.getElementById('ind-cal-protein').textContent = `${macros.proteinGrams}g (${macros.proteinCalories} kkal)`;
    document.getElementById('ind-cal-fat').textContent = `${macros.fatGrams}g (${macros.fatCalories} kkal)`;

    const isDark = document.documentElement.classList.contains('dark');
    FitnessCharts.renderMacroChart('ind-cal-macro-chart', macros, isDark);
}

// 3. Individual Body Fat Calculator
function calculateIndividualBodyFat() {
    const gender = document.querySelector('input[name="bf-gender"]:checked').value;
    const height = parseFloat(document.getElementById('bf-height').value);
    const weight = parseFloat(document.getElementById('bf-weight').value);
    const neck = parseFloat(document.getElementById('bf-neck').value);
    const waist = parseFloat(document.getElementById('bf-waist').value);
    const hip = parseFloat(document.getElementById('bf-hip')?.value) || 0;

    const res = FitnessCalculator.calculateBodyFatNavy(gender, height, waist, neck, hip, weight);
    if (!res) {
        alert('Mohon periksa kembali ukuran lingkar tubuh Anda. Pastikan lingkar pinggang lebih besar dari leher.');
        return;
    }

    document.getElementById('bf-result-box').classList.remove('hidden');
    document.getElementById('bf-result-percent').textContent = `${res.bodyFatPercent}%`;
    document.getElementById('bf-result-category').textContent = res.category;
    document.getElementById('bf-result-category').className = `px-3 py-1 rounded-full text-xs font-bold ${res.colorClass}`;
    document.getElementById('bf-fatmass').textContent = `${res.fatMassKg} kg`;
    document.getElementById('bf-leanmass').textContent = `${res.leanMassKg} kg`;
}

// 4. Individual Hydration Calculator
function calculateIndividualHydration() {
    const weight = parseFloat(document.getElementById('hydro-weight').value);
    const exercise = parseInt(document.getElementById('hydro-exercise').value) || 0;

    const res = FitnessCalculator.calculateHydration(weight, exercise);
    if (!res) return;

    document.getElementById('hydro-result-box').classList.remove('hidden');
    document.getElementById('hydro-res-liters').textContent = `${res.totalLiters} L`;
    document.getElementById('hydro-res-glasses').textContent = `~${res.totalGlasses} Gelas`;
    document.getElementById('hydro-res-base').textContent = `${res.baseWaterMl} ml`;
    document.getElementById('hydro-res-exercise').textContent = `+${res.exerciseWaterMl} ml`;
}

// 5. Individual Heart Rate Zones
function calculateIndividualHeartRate() {
    const age = parseInt(document.getElementById('hr-age').value) || 25;
    const resting = parseInt(document.getElementById('hr-resting').value) || 70;

    const res = FitnessCalculator.calculateHeartRateZones(age, resting);
    if (!res) return;

    document.getElementById('hr-result-box').classList.remove('hidden');
    document.getElementById('hr-max-display').textContent = `${res.maxHr} BPM`;

    const container = document.getElementById('hr-zones-cards-container');
    if (container) {
        container.innerHTML = res.zones.map(z => `
            <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 shadow-xs hover:shadow-md transition">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Zona ${z.zone} (${z.minPercent}-${z.maxPercent}%)</span>
                    <span class="px-2.5 py-0.5 rounded text-xs font-bold ${z.badgeColor}">${z.minBpm} - ${z.maxBpm} BPM</span>
                </div>
                <h4 class="font-bold text-slate-800 dark:text-slate-100 text-sm mb-1">${z.name}</h4>
                <p class="text-xs text-slate-600 dark:text-slate-400">${z.benefit}</p>
            </div>
        `).join('');
    }

    const isDark = document.documentElement.classList.contains('dark');
    FitnessCharts.renderHeartRateChart('ind-hr-chart', res.zones, isDark);
}

// 6. Individual 1RM Strength Calculator
function calculateIndividual1RM() {
    const weight = parseFloat(document.getElementById('onerm-weight').value);
    const reps = parseInt(document.getElementById('onerm-reps').value);

    const res = FitnessCalculator.calculateOneRepMax(weight, reps);
    if (!res) return;

    document.getElementById('onerm-result-box').classList.remove('hidden');
    document.getElementById('onerm-max-display').textContent = `${res.oneRepMax} kg`;

    const tbody = document.getElementById('onerm-table-body');
    if (tbody) {
        tbody.innerHTML = res.percentages.map(row => `
            <tr class="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td class="py-2.5 px-3 font-bold text-indigo-600 dark:text-indigo-400">${row.pct}%</td>
                <td class="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-100">${row.loadKg} kg</td>
                <td class="py-2.5 px-3 text-slate-600 dark:text-slate-300">${row.reps}</td>
                <td class="py-2.5 px-3 text-xs text-slate-500 dark:text-slate-400">${row.goal}</td>
            </tr>
        `).join('');
    }
}
