/**
 * FitCalc Pro - Modul Visualisasi Grafik dengan Chart.js
 */

const FitnessCharts = {
    macroChartInstance: null,
    historyChartInstance: null,
    heartRateChartInstance: null,

    /**
     * Render atau Update Grafik Donut Makronutrisi
     * @param {string} canvasId 
     * @param {object} macroData - { carbGrams, proteinGrams, fatGrams, carbPercent, proteinPercent, fatPercent }
     * @param {boolean} isDarkMode
     */
    renderMacroChart(canvasId, macroData, isDarkMode = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (this.macroChartInstance) {
            this.macroChartInstance.destroy();
        }

        const textColor = isDarkMode ? '#cbd5e1' : '#475569';

        this.macroChartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [
                    `Karbohidrat (${macroData.carbPercent}%)`,
                    `Protein (${macroData.proteinPercent}%)`,
                    `Lemak Sehat (${macroData.fatPercent}%)`
                ],
                datasets: [{
                    data: [macroData.carbGrams, macroData.proteinGrams, macroData.fatGrams],
                    backgroundColor: [
                        '#3b82f6', // Biru - Karbohidrat
                        '#10b981', // Hijau Zamrud - Protein
                        '#f59e0b'  // Kuning Amber - Lemak
                    ],
                    borderWidth: 2,
                    borderColor: isDarkMode ? '#1e293b' : '#ffffff',
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: textColor,
                            font: {
                                size: 12,
                                family: "'Inter', sans-serif",
                                weight: 500
                            },
                            padding: 14,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const grams = context.raw;
                                const calories = context.dataIndex === 2 ? grams * 9 : grams * 4;
                                return ` ${context.label.split(' ')[0]}: ${grams}g (~${calories} kkal)`;
                            }
                        }
                    }
                },
                cutout: '72%'
            }
        });
    },

    /**
     * Render Grafik Garis Riwayat Berat Badan & BMI
     * @param {string} canvasId 
     * @param {Array} historyData - Array of { date, weight, bmi }
     * @param {boolean} isDarkMode 
     */
    renderHistoryChart(canvasId, historyData, isDarkMode = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (this.historyChartInstance) {
            this.historyChartInstance.destroy();
        }

        if (!historyData || historyData.length === 0) {
            return;
        }

        const labels = historyData.map(item => item.date);
        const weightData = historyData.map(item => item.weight);
        const bmiData = historyData.map(item => item.bmi);

        const textColor = isDarkMode ? '#94a3b8' : '#64748b';
        const gridColor = isDarkMode ? 'rgba(255, 255, 255, 0.07)' : 'rgba(0, 0, 0, 0.06)';

        this.historyChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Berat Badan (kg)',
                        data: weightData,
                        borderColor: '#6366f1', // Indigo
                        backgroundColor: 'rgba(99, 102, 241, 0.12)',
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#6366f1',
                        pointBorderColor: '#fff',
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Indeks BMI',
                        data: bmiData,
                        borderColor: '#06b6d4', // Cyan
                        backgroundColor: 'transparent',
                        borderDash: [5, 5],
                        tension: 0.35,
                        pointBackgroundColor: '#06b6d4',
                        pointBorderColor: '#fff',
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: textColor,
                            font: { family: "'Inter', sans-serif", size: 12 },
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        padding: 10,
                        boxPadding: 4
                    }
                },
                scales: {
                    x: {
                        ticks: { color: textColor },
                        grid: { color: gridColor }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Berat (kg)',
                            color: textColor
                        },
                        ticks: { color: textColor },
                        grid: { color: gridColor }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'BMI',
                            color: textColor
                        },
                        ticks: { color: textColor },
                        grid: { drawOnChartArea: false }
                    }
                }
            }
        });
    },

    /**
     * Render Grafik Batang Horizontal Zona Denyut Jantung
     * @param {string} canvasId 
     * @param {Array} zones - Array zona detak jantung
     * @param {boolean} isDarkMode 
     */
    renderHeartRateChart(canvasId, zones, isDarkMode = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (this.heartRateChartInstance) {
            this.heartRateChartInstance.destroy();
        }

        const labels = zones.map(z => `Zona ${z.zone}: ${z.minBpm}-${z.maxBpm} BPM`);
        const dataValues = zones.map(z => z.maxBpm);
        const colors = zones.map(z => z.color);
        const textColor = isDarkMode ? '#cbd5e1' : '#475569';

        this.heartRateChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Target Denyut Jantung (BPM)',
                    data: dataValues,
                    backgroundColor: colors,
                    borderRadius: 6,
                    borderWidth: 0
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            afterLabel: function(context) {
                                const zone = zones[context.dataIndex];
                                return `${zone.name}\n${zone.benefit}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: textColor },
                        grid: { color: isDarkMode ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)' },
                        title: {
                            display: true,
                            text: 'Denyut Jantung (BPM)',
                            color: textColor
                        }
                    },
                    y: {
                        ticks: { color: textColor, font: { size: 11 } },
                        grid: { display: false }
                    }
                }
            }
        });
    }
};

if (typeof window !== 'undefined') {
    window.FitnessCharts = FitnessCharts;
}
