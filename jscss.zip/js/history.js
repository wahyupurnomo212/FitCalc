/**
 * FitCalc Pro - Modul Pengelolaan Riwayat (LocalStorage)
 */

const FitnessHistory = {
    STORAGE_KEY: 'fitcalc_pro_history_v1',

    /**
     * Dapatkan semua data riwayat dari LocalStorage
     * @returns {Array} List entri riwayat
     */
    getAll() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            return data ? JSON.parse(data) : [];
        } catch (e) {
            console.error('Gagal membaca history dari LocalStorage:', e);
            return [];
        }
    },

    /**
     * Simpan entri baru ke riwayat
     * @param {object} entry 
     * @returns {boolean} sukses atau gagal
     */
    add(entry) {
        try {
            const list = this.getAll();
            const newEntry = {
                id: 'fit_' + Date.now(),
                timestamp: new Date().toISOString(),
                date: entry.date || new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
                name: entry.name || 'Pengguna',
                gender: entry.gender || 'male',
                age: entry.age || 25,
                height: entry.height || 170,
                weight: entry.weight || 65,
                bmi: entry.bmi || 22.5,
                bmiCategory: entry.bmiCategory || 'Normal',
                tdee: entry.tdee || 2000,
                bodyFat: entry.bodyFat || null,
                score: entry.score || 85,
                goal: entry.goal || 'Pertahankan Berat'
            };

            list.unshift(newEntry); // Taruh di awal
            // Batasi hingga 50 entri terakhir
            const trimmedList = list.slice(0, 50);
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(trimmedList));
            return true;
        } catch (e) {
            console.error('Gagal menyimpan ke LocalStorage:', e);
            return false;
        }
    },

    /**
     * Hapus entri berdasarkan ID
     * @param {string} id 
     */
    remove(id) {
        try {
            const list = this.getAll().filter(item => item.id !== id);
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(list));
            return true;
        } catch (e) {
            console.error('Gagal menghapus entri:', e);
            return false;
        }
    },

    /**
     * Bersihkan semua riwayat
     */
    clearAll() {
        try {
            localStorage.removeItem(this.STORAGE_KEY);
            return true;
        } catch (e) {
            console.error('Gagal membersihkan riwayat:', e);
            return false;
        }
    },

    /**
     * Muat data sampel awal jika riwayat masih kosong (agar grafik langsung menarik dilihat)
     */
    loadSampleDataIfEmpty() {
        const current = this.getAll();
        if (current.length === 0) {
            const now = new Date();
            const samples = [
                {
                    id: 'fit_sample_1',
                    timestamp: new Date(now.getTime() - 60 * 24 * 3600 * 1000).toISOString(),
                    date: new Date(now.getTime() - 60 * 24 * 3600 * 1000).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
                    name: 'Wahyu',
                    gender: 'male',
                    age: 26,
                    height: 172,
                    weight: 76.5,
                    bmi: 25.9,
                    bmiCategory: 'Obesitas 1',
                    tdee: 2350,
                    bodyFat: 23.5,
                    score: 68,
                    goal: 'Turunkan Lemak'
                },
                {
                    id: 'fit_sample_2',
                    timestamp: new Date(now.getTime() - 40 * 24 * 3600 * 1000).toISOString(),
                    date: new Date(now.getTime() - 40 * 24 * 3600 * 1000).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
                    name: 'Wahyu',
                    gender: 'male',
                    age: 26,
                    height: 172,
                    weight: 73.8,
                    bmi: 24.9,
                    bmiCategory: 'Overweight',
                    tdee: 2280,
                    bodyFat: 21.2,
                    score: 75,
                    goal: 'Turunkan Lemak'
                },
                {
                    id: 'fit_sample_3',
                    timestamp: new Date(now.getTime() - 20 * 24 * 3600 * 1000).toISOString(),
                    date: new Date(now.getTime() - 20 * 24 * 3600 * 1000).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
                    name: 'Wahyu',
                    gender: 'male',
                    age: 26,
                    height: 172,
                    weight: 70.2,
                    bmi: 23.7,
                    bmiCategory: 'Overweight Ringan',
                    tdee: 2240,
                    bodyFat: 18.8,
                    score: 83,
                    goal: 'Turunkan Lemak'
                },
                {
                    id: 'fit_sample_4',
                    timestamp: now.toISOString(),
                    date: now.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
                    name: 'Wahyu',
                    gender: 'male',
                    age: 26,
                    height: 172,
                    weight: 67.5,
                    bmi: 22.8,
                    bmiCategory: 'Ideal (Normal)',
                    tdee: 2200,
                    bodyFat: 16.5,
                    score: 92,
                    goal: 'Pertahankan Berat'
                }
            ];
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(samples.reverse()));
        }
    },

    /**
     * Ekspor Data Riwayat ke CSV
     */
    exportToCSV() {
        const list = this.getAll();
        if (list.length === 0) {
            alert('Belum ada riwayat data untuk diekspor!');
            return;
        }

        const headers = ['Tanggal', 'Nama', 'Gender', 'Usia', 'Tinggi (cm)', 'Berat (kg)', 'BMI', 'Kategori BMI', 'TDEE (kkal)', 'Lemak Tubuh (%)', 'Skor Kebugaran', 'Target'];
        const rows = list.map(item => [
            `"${item.date}"`,
            `"${item.name}"`,
            `"${item.gender === 'male' ? 'Laki-laki' : 'Perempuan'}"`,
            item.age,
            item.height,
            item.weight,
            item.bmi,
            `"${item.bmiCategory}"`,
            item.tdee,
            item.bodyFat || '-',
            item.score,
            `"${item.goal}"`
        ]);

        const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' 
            + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `Riwayat_Kebugaran_FitCalc_${new Date().toISOString().slice(0, 10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

if (typeof window !== 'undefined') {
    window.FitnessHistory = FitnessHistory;
}
