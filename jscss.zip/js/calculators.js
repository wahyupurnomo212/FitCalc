/**
 * FitCalc Pro - Kalkulator Kebugaran Tubuh
 * Modul Formula & Algoritma Perhitungan Kebugaran Sains Terapan
 */

const FitnessCalculator = {
    /**
     * Hitung Indeks Massa Tubuh (BMI / IMT)
     * @param {number} weightKg - Berat badan dalam kilogram
     * @param {number} heightCm - Tinggi badan dalam sentimeter
     * @returns {object} BMI, Kategori WHO, Kategori Asia-Pasifik, Warna, dan Rentang Berat Sehat
     */
    calculateBMI(weightKg, heightCm) {
        if (!weightKg || !heightCm || weightKg <= 0 || heightCm <= 0) return null;
        
        const heightM = heightCm / 100;
        const bmi = weightKg / (heightM * heightM);
        const roundedBmi = parseFloat(bmi.toFixed(1));

        // Rentang berat normal WHO (18.5 - 24.9) & Asia-Pasifik Kemenkes (18.5 - 22.9)
        const minNormalWeight = parseFloat((18.5 * (heightM * heightM)).toFixed(1));
        const maxNormalWeightAsia = parseFloat((22.9 * (heightM * heightM)).toFixed(1));
        const maxNormalWeightWHO = parseFloat((24.9 * (heightM * heightM)).toFixed(1));

        // Klasifikasi Kemenkes RI / Asia Pasifik
        let categoryAsia = '';
        let colorClass = '';
        let statusBadge = '';
        let advice = '';

        if (roundedBmi < 17.0) {
            categoryAsia = 'Kurus Berat (Underweight Tingkat Berat)';
            colorClass = 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800';
            statusBadge = 'Perlu Perhatian';
            advice = 'Berat badan Anda berada jauh di bawah rentang sehat. Disarankan meningkatkan asupan kalori bernutrisi dan konsultasi dengan dokter/ahli gizi.';
        } else if (roundedBmi < 18.5) {
            categoryAsia = 'Kurus Ringan (Underweight Ringan)';
            colorClass = 'text-cyan-600 bg-cyan-50 border-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-400 dark:border-cyan-800';
            statusBadge = 'Di Bawah Normal';
            advice = 'Berat badan Anda sedikit di bawah normal. Tambah asupan protein dan karbohidrat kompleks serta latihan beban.';
        } else if (roundedBmi <= 22.9) {
            categoryAsia = 'Normal / Ideal (Standar Asia-Pasifik)';
            colorClass = 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800';
            statusBadge = 'Ideal & Sehat';
            advice = 'Selamat! Berat badan Anda berada di rentang ideal. Pertahankan pola makan seimbang dan aktivitas fisik teratur.';
        } else if (roundedBmi <= 24.9) {
            categoryAsia = 'Kelebihan Berat Badan Ringan (Overweight)';
            colorClass = 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800';
            statusBadge = 'Waspada Overweight';
            advice = 'Anda sedikit di atas rentang ideal Asia Pasifik. Jaga porsi makan dan tingkatkan aktivitas kardio serta latihan kekuatan.';
        } else if (roundedBmi <= 29.9) {
            categoryAsia = 'Obesitas Tingkat 1';
            colorClass = 'text-orange-600 bg-orange-50 border-orange-200 dark:bg-orange-950/40 dark:text-orange-400 dark:border-orange-800';
            statusBadge = 'Obesitas Ringan';
            advice = 'Berat badan berlebih meningkatkan risiko kardiovaskular. Terapkan defisit kalori moderat dan tingkatkan jalan kaki / kardio harian.';
        } else {
            categoryAsia = 'Obesitas Tingkat 2 (Tinggi)';
            colorClass = 'text-rose-600 bg-rose-50 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800';
            statusBadge = 'Perlu Tindakan';
            advice = 'Sangat dianjurkan merencanakan program penurunan berat badan terstruktur dengan bantuan profesional kesehatan.';
        }

        // Posisi persentase jarum gauge (rentang 10 sampai 40 BMI)
        let gaugePercentage = ((roundedBmi - 10) / (40 - 10)) * 100;
        if (gaugePercentage < 0) gaugePercentage = 0;
        if (gaugePercentage > 100) gaugePercentage = 100;

        return {
            bmi: roundedBmi,
            category: categoryAsia,
            statusBadge,
            colorClass,
            advice,
            idealWeightMin: minNormalWeight,
            idealWeightMax: maxNormalWeightAsia,
            idealWeightMaxWHO: maxNormalWeightWHO,
            gaugePercentage: Math.round(gaugePercentage)
        };
    },

    /**
     * Hitung BMR (Basal Metabolic Rate) menggunakan Rumus Mifflin-St Jeor
     * @param {string} gender - 'male' | 'female'
     * @param {number} weightKg - Berat badan (kg)
     * @param {number} heightCm - Tinggi badan (cm)
     * @param {number} age - Usia (tahun)
     * @returns {number} BMR dalam kcal
     */
    calculateBMR(gender, weightKg, heightCm, age) {
        if (!weightKg || !heightCm || !age) return 0;
        // Mifflin - St Jeor Equation
        // Pria: (10 × berat) + (6.25 × tinggi) - (5 × usia) + 5
        // Wanita: (10 × berat) + (6.25 × tinggi) - (5 × usia) - 161
        const base = (10 * weightKg) + (6.25 * heightCm) - (5 * age);
        const bmr = gender === 'male' ? base + 5 : base - 161;
        return Math.round(bmr);
    },

    /**
     * Hitung TDEE (Total Daily Energy Expenditure) berdasarkan faktor aktivitas
     * @param {number} bmr - BMR dalam kcal
     * @param {number|string} activityLevel - Pengali aktivitas (1.2 s.d 1.9)
     * @returns {number} TDEE dalam kcal
     */
    calculateTDEE(bmr, activityLevel) {
        const factor = parseFloat(activityLevel) || 1.2;
        return Math.round(bmr * factor);
    },

    /**
     * Hitung Rekomendasi Kalori & Makronutrisi sesuai Sasaran Tubuh
     * @param {number} tdee - TDEE kalori harian
     * @param {string} goal - 'cut_mild' | 'cut_opt' | 'maintain' | 'bulk_lean' | 'bulk_fast'
     * @param {string} dietType - 'balanced' | 'high_protein' | 'low_carb' | 'keto'
     * @returns {object} Target Kalori dan gram Protein, Karbohidrat, Lemak
     */
    calculateMacros(tdee, goal = 'maintain', dietType = 'balanced') {
        let calorieTarget = tdee;

        // Penyesuaian kalori target
        switch (goal) {
            case 'cut_mild':
                calorieTarget = tdee - 300; // Defisit ringan
                break;
            case 'cut_opt':
                calorieTarget = Math.round(tdee * 0.80); // Defisit 20% (~400-500 kcal)
                break;
            case 'cut_aggressive':
                calorieTarget = Math.round(tdee * 0.75); // Defisit 25%
                break;
            case 'bulk_lean':
                calorieTarget = tdee + 300; // Surplus bersih
                break;
            case 'bulk_fast':
                calorieTarget = Math.round(tdee * 1.15); // Surplus 15%
                break;
            case 'maintain':
            default:
                calorieTarget = tdee;
                break;
        }

        // Distribusi Makro: Karbo (4 kcal/g), Protein (4 kcal/g), Lemak (9 kcal/g)
        let ratio = { carb: 0.50, protein: 0.25, fat: 0.25 }; // Default Balanced

        if (dietType === 'high_protein') {
            ratio = { carb: 0.35, protein: 0.40, fat: 0.25 };
        } else if (dietType === 'low_carb') {
            ratio = { carb: 0.20, protein: 0.40, fat: 0.40 };
        } else if (dietType === 'keto') {
            ratio = { carb: 0.05, protein: 0.25, fat: 0.70 };
        }

        const carbCalories = calorieTarget * ratio.carb;
        const proteinCalories = calorieTarget * ratio.protein;
        const fatCalories = calorieTarget * ratio.fat;

        return {
            targetCalories: calorieTarget,
            calorieDifference: calorieTarget - tdee,
            carbGrams: Math.round(carbCalories / 4),
            proteinGrams: Math.round(proteinCalories / 4),
            fatGrams: Math.round(fatCalories / 9),
            carbCalories: Math.round(carbCalories),
            proteinCalories: Math.round(proteinCalories),
            fatCalories: Math.round(fatCalories),
            carbPercent: Math.round(ratio.carb * 100),
            proteinPercent: Math.round(ratio.protein * 100),
            fatPercent: Math.round(ratio.fat * 100)
        };
    },

    /**
     * Hitung Estimasi Persentase Lemak Tubuh (U.S. Navy Method)
     * @param {string} gender - 'male' | 'female'
     * @param {number} heightCm - Tinggi badan (cm)
     * @param {number} waistCm - Lingkar pinggang (cm)
     * @param {number} neckCm - Lingkar leher (cm)
     * @param {number} hipCm - Lingkar pinggul (cm, wajib untuk wanita)
     * @param {number} weightKg - Berat badan (kg) untuk estimasi massa lemak
     * @returns {object} Persentase Lemak, Kategori, Massa Lemak, Massa Bebas Lemak
     */
    calculateBodyFatNavy(gender, heightCm, waistCm, neckCm, hipCm = 0, weightKg = 0) {
        if (!heightCm || !waistCm || !neckCm) return null;

        let bodyFat = 0;

        if (gender === 'male') {
            const diff = waistCm - neckCm;
            if (diff <= 0) return null;
            // Rumus Pria US Navy:
            // 86.010 * log10(waist - neck) - 70.041 * log10(height) + 36.76
            bodyFat = 86.010 * Math.log10(diff) - 70.041 * Math.log10(heightCm) + 36.76;
        } else {
            if (!hipCm || hipCm <= 0) return null;
            const sum = waistCm + hipCm - neckCm;
            if (sum <= 0) return null;
            // Rumus Wanita US Navy:
            // 163.205 * log10(waist + hip - neck) - 97.684 * log10(height) - 78.387
            bodyFat = 163.205 * Math.log10(sum) - 97.684 * Math.log10(heightCm) - 78.387;
        }

        bodyFat = Math.max(3, Math.min(60, bodyFat));
        const roundedFat = parseFloat(bodyFat.toFixed(1));

        // Klasifikasi Lemak Tubuh menurut American Council on Exercise (ACE)
        let category = '';
        let colorClass = '';

        if (gender === 'male') {
            if (roundedFat < 6) {
                category = 'Lemak Esensial (Sangat Rendah)';
                colorClass = 'text-amber-600 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-400';
            } else if (roundedFat <= 13) {
                category = 'Tingkat Atlet (Sangat Ramping)';
                colorClass = 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400';
            } else if (roundedFat <= 17) {
                category = 'Bugar (Fitness)';
                colorClass = 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400';
            } else if (roundedFat <= 24) {
                category = 'Rata-rata Sehat (Acceptable)';
                colorClass = 'text-blue-600 bg-blue-50 dark:bg-blue-950/40 dark:text-blue-400';
            } else {
                category = 'Tinggi / Berlebih (Obese)';
                colorClass = 'text-rose-600 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-400';
            }
        } else {
            if (roundedFat < 14) {
                category = 'Lemak Esensial (Sangat Rendah)';
                colorClass = 'text-amber-600 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-400';
            } else if (roundedFat <= 20) {
                category = 'Tingkat Atlet (Sangat Ramping)';
                colorClass = 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400';
            } else if (roundedFat <= 24) {
                category = 'Bugar (Fitness)';
                colorClass = 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400';
            } else if (roundedFat <= 31) {
                category = 'Rata-rata Sehat (Acceptable)';
                colorClass = 'text-blue-600 bg-blue-50 dark:bg-blue-950/40 dark:text-blue-400';
            } else {
                category = 'Tinggi / Berlebih (Obese)';
                colorClass = 'text-rose-600 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-400';
            }
        }

        const fatMassKg = weightKg > 0 ? parseFloat(((weightKg * roundedFat) / 100).toFixed(1)) : 0;
        const leanMassKg = weightKg > 0 ? parseFloat((weightKg - fatMassKg).toFixed(1)) : 0;

        return {
            bodyFatPercent: roundedFat,
            category,
            colorClass,
            fatMassKg,
            leanMassKg
        };
    },

    /**
     * Hitung Kebutuhan Cairan & Air Minum Harian
     * @param {number} weightKg - Berat badan (kg)
     * @param {number} exerciseMinutesDaily - Durasi olahraga harian (menit)
     * @returns {object} Total ml, Liter, Jumlah Gelas (250ml)
     */
    calculateHydration(weightKg, exerciseMinutesDaily = 0) {
        if (!weightKg || weightKg <= 0) return null;
        
        // 35 ml per kg berat badan
        const baseWaterMl = weightKg * 35;
        // Tambahan ~350 ml per 30 menit olahraga
        const exerciseWaterMl = (exerciseMinutesDaily / 30) * 350;
        
        const totalMl = Math.round(baseWaterMl + exerciseWaterMl);
        const totalLiters = parseFloat((totalMl / 1000).toFixed(1));
        const totalGlasses = Math.ceil(totalMl / 250);

        return {
            totalMl,
            totalLiters,
            totalGlasses,
            baseWaterMl: Math.round(baseWaterMl),
            exerciseWaterMl: Math.round(exerciseWaterMl)
        };
    },

    /**
     * Hitung Target Denyut Jantung (Heart Rate Zones) berdasarkan Usia & Resting HR
     * Menggunakan Formula Karvonen & Standar Max HR (220 - Usia)
     * @param {number} age - Usia dalam tahun
     * @param {number} restingHr - Denyut jantung istirahat (opsional, default 70 bpm)
     * @returns {object} Max HR dan 5 Zona Latihan
     */
    calculateHeartRateZones(age, restingHr = 70) {
        if (!age || age <= 0) return null;

        const maxHr = 220 - age;
        const rHr = restingHr > 30 && restingHr < 120 ? restingHr : 70;
        const hrReserve = maxHr - rHr; // Karvonen Formula

        const zones = [
            {
                zone: 1,
                name: 'Pemulihan Aktif (Active Recovery)',
                minPercent: 50,
                maxPercent: 60,
                minBpm: Math.round(rHr + (hrReserve * 0.50)),
                maxBpm: Math.round(rHr + (hrReserve * 0.60)),
                benefit: 'Meningkatkan sirkulasi darah, pemulihan otot, dan pemanasan.',
                color: '#38bdf8', // sky-400
                badgeColor: 'bg-sky-100 text-sky-800 dark:bg-sky-950/50 dark:text-sky-300'
            },
            {
                zone: 2,
                name: 'Pembakaran Lemak & Ausdauer (Zone 2 Endurance)',
                minPercent: 60,
                maxPercent: 70,
                minBpm: Math.round(rHr + (hrReserve * 0.60)),
                maxBpm: Math.round(rHr + (hrReserve * 0.70)),
                benefit: 'Mengoptimalkan oksidasi lemak, melatih mitokondria, fondasi kardio terbaik.',
                color: '#34d399', // emerald-400
                badgeColor: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
            },
            {
                zone: 3,
                name: 'Kapasitas Aerobik (Aerobic Fitness)',
                minPercent: 70,
                maxPercent: 80,
                minBpm: Math.round(rHr + (hrReserve * 0.70)),
                maxBpm: Math.round(rHr + (hrReserve * 0.80)),
                benefit: 'Meningkatkan volume paru-paru, kapasitas jantung, dan stamina keseluruhan.',
                color: '#facc15', // amber-400
                badgeColor: 'bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
            },
            {
                zone: 4,
                name: 'Ambang Laktat (Anaerobic Threshold)',
                minPercent: 80,
                maxPercent: 90,
                minBpm: Math.round(rHr + (hrReserve * 0.80)),
                maxBpm: Math.round(rHr + (hrReserve * 0.90)),
                benefit: 'Meningkatkan daya tahan asam laktat, kecepatan lari cepat, performa atletik.',
                color: '#fb923c', // orange-400
                badgeColor: 'bg-orange-100 text-orange-800 dark:bg-orange-950/50 dark:text-orange-300'
            },
            {
                zone: 5,
                name: 'Puncak Maksimal (Redline / VO2 Max)',
                minPercent: 90,
                maxPercent: 100,
                minBpm: Math.round(rHr + (hrReserve * 0.90)),
                maxBpm: maxHr,
                benefit: 'Maksimum usaha (HIIT sprint). Melatih serabut otot cepat & kapasitas tertinggi.',
                color: '#f43f5e', // rose-500
                badgeColor: 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300'
            }
        ];

        return {
            maxHr,
            restingHr: rHr,
            zones
        };
    },

    /**
     * Hitung Berat Badan Ideal dengan Beberapa Rumus Ilmiah Populer
     * (Devine, Robinson, Miller, dan Broca)
     * @param {string} gender - 'male' | 'female'
     * @param {number} heightCm - Tinggi badan (cm)
     * @returns {object} Berbagai estimasi berat ideal
     */
    calculateIdealWeight(gender, heightCm) {
        if (!heightCm || heightCm <= 100) return null;

        const inchesOver60 = (heightCm / 2.54) - 60;
        const validInches = Math.max(0, inchesOver60);

        // Rumus Devine (1974)
        const devine = gender === 'male' 
            ? 50.0 + (2.3 * validInches)
            : 45.5 + (2.3 * validInches);

        // Rumus Robinson (1983)
        const robinson = gender === 'male'
            ? 52.0 + (1.9 * validInches)
            : 49.0 + (1.7 * validInches);

        // Rumus Broca (Diadaptasi Kemenkes RI)
        // Pria: (TB - 100) - 10%
        // Wanita: (TB - 100) - 15%
        const brocaBase = heightCm - 100;
        const broca = gender === 'male'
            ? brocaBase - (brocaBase * 0.10)
            : brocaBase - (brocaBase * 0.15);

        // Rata-rata
        const average = parseFloat(((devine + robinson + broca) / 3).toFixed(1));

        return {
            devine: parseFloat(devine.toFixed(1)),
            robinson: parseFloat(robinson.toFixed(1)),
            broca: parseFloat(broca.toFixed(1)),
            averageIdealWeight: average
        };
    },

    /**
     * Hitung 1 Rep Max (1RM) untuk Latihan Kekuatan
     * Formula Epley & Brzycki
     * @param {number} weightLiftedKg - Beban yang diangkat (kg)
     * @param {number} reps - Jumlah repetisi (1-12)
     * @returns {object} Estimasi 1RM dan persentase beban latihan
     */
    calculateOneRepMax(weightLiftedKg, reps) {
        if (!weightLiftedKg || !reps || reps <= 0) return null;

        // Epley Formula: 1RM = Weight * (1 + Reps / 30)
        const epley = weightLiftedKg * (1 + (reps / 30));
        
        // Brzycki Formula: 1RM = Weight * (36 / (37 - Reps))
        const brzycki = reps < 37 ? weightLiftedKg * (36 / (37 - reps)) : epley;

        const oneRepMax = parseFloat(((epley + brzycki) / 2).toFixed(1));

        const percentages = [
            { pct: 95, reps: '1-2 Reps', goal: 'Kekuatan Maksimal Murni (Max Strength)', loadKg: parseFloat((oneRepMax * 0.95).toFixed(1)) },
            { pct: 85, reps: '4-6 Reps', goal: 'Kekuatan & Densitas Otot', loadKg: parseFloat((oneRepMax * 0.85).toFixed(1)) },
            { pct: 75, reps: '8-10 Reps', goal: 'Hipertrofi / Pertumbuhan Otot Ideal', loadKg: parseFloat((oneRepMax * 0.75).toFixed(1)) },
            { pct: 65, reps: '12-15 Reps', goal: 'Ketahanan Otot & Definisi (Endurance)', loadKg: parseFloat((oneRepMax * 0.65).toFixed(1)) },
            { pct: 50, reps: '20+ Reps', goal: 'Pemanasan & Daya Tahan Panjang', loadKg: parseFloat((oneRepMax * 0.50).toFixed(1)) }
        ];

        return {
            oneRepMax,
            percentages
        };
    },

    /**
     * Hitung Skor Kesehatan & Kebugaran Terintegrasi (0 - 100)
     * @param {object} params - { bmi, bodyFat, activityLevel, waterLiters }
     * @returns {object} Nilai skor 1-100, label kategori, ringkasan saran
     */
    calculateFitnessScore({ bmi, bodyFat, activityLevel = 1.2, hydrationPercent = 100 }) {
        let score = 100;

        // Penilaian Berdasarkan BMI
        if (bmi < 18.5) {
            score -= Math.min(25, (18.5 - bmi) * 8);
        } else if (bmi > 22.9 && bmi <= 25) {
            score -= (bmi - 22.9) * 4;
        } else if (bmi > 25) {
            score -= Math.min(40, 8 + (bmi - 25) * 5);
        }

        // Penilaian Berdasarkan Tingkat Aktivitas (1.2 s/d 1.9)
        const actNum = parseFloat(activityLevel);
        if (actNum <= 1.2) {
            score -= 15; // Sedentary penalty
        } else if (actNum <= 1.375) {
            score -= 5;
        } else if (actNum >= 1.55) {
            score += 5; // Bonus aktif
        }

        // Penilaian Lemak Tubuh jika ada
        if (bodyFat) {
            if (bodyFat > 28) score -= 10;
            else if (bodyFat <= 20) score += 5;
        }

        score = Math.max(20, Math.min(100, Math.round(score)));

        let ratingLabel = '';
        let badgeColor = '';

        if (score >= 88) {
            ratingLabel = 'Sangat Prima (Excellent)';
            badgeColor = 'bg-emerald-500 text-white';
        } else if (score >= 75) {
            ratingLabel = 'Kebugaran Baik (Good)';
            badgeColor = 'bg-teal-500 text-white';
        } else if (score >= 60) {
            ratingLabel = 'Cukup / Perlu Ditingkatkan (Fair)';
            badgeColor = 'bg-amber-500 text-white';
        } else {
            ratingLabel = 'Perlu Perhatian Khusus (Needs Attention)';
            badgeColor = 'bg-rose-500 text-white';
        }

        return {
            score,
            ratingLabel,
            badgeColor
        };
    }
};

// Export to window
if (typeof window !== 'undefined') {
    window.FitnessCalculator = FitnessCalculator;
}
